package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/qlnv")
public class NhanVienController {

	@Autowired
	private NhanVienRepository nhanvienRepo;
	
	@GetMapping("/nhanvien")
	public @ResponseBody Iterable<NhanVien> layKetQua(){
		Iterable<NhanVien> result  = nhanvienRepo.findAll();
		return result;
	}
	
	
	
	
}
