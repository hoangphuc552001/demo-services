package com.example.demo;


import org.springframework.data.repository.CrudRepository;


public interface NhanVienRepository extends CrudRepository<NhanVien, Long> {

		
	
}
