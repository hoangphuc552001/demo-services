package com.example.qltc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qltc2Application {

	public static void main(String[] args) {
		SpringApplication.run(Qltc2Application.class, args);
	}

}
