package com.example.qltc;

import org.springframework.data.repository.CrudRepository;

public interface QLTC_NhanVienRepo extends CrudRepository<NhanVien, Long> {

}
