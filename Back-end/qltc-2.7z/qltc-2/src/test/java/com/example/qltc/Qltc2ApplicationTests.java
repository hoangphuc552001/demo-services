package com.example.qltc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qltc2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
